Abdul Asad Raza Portfolio

Open index.html in a browser to preview the portfolio.
Before publishing, replace the education placeholder, add real projects, and add your email/GitHub links.
The technologies HTML5, CSS3, JavaScript, and Java were carried over from the skills shown in your existing portfolio; confirm them before publishing.
